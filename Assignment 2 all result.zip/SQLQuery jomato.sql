create database jomato;
select * from Jomato
USE jomato;

create function f_quickchickenbites(@restauranttype varchar(100))
returns table
as
return (
 select *,
 stuff(restauranttype, charindex('quick bites', restauranttype), len('quick bites'), 'chicken') as quickchickenbites from jomato
 where upper(restauranttype) like '%' + upper(@restauranttype) + '%' )

 select * from f_quickchickenbites ('quick bites')
 select * from f_quickchickenbites ('quick chicken bites') 


2 

create function second_question () 
returns table
as
return
select cuisinestype ,restaurantname from jomato where rating in (select max(rating)�from�jomato�)

select * from second_question()

3
		SELECT 
    Rating,
    CASE 
        WHEN Rating > 4 THEN 'Excellent'
        WHEN Rating > 3.5 AND Rating <= 4 THEN 'Good'
        WHEN Rating > 3 AND Rating <= 3.5 THEN 'Average'
        WHEN Rating <= 3 THEN 'Bad'
    END AS Rating 
From�jomato

	4
	SELECT
    restaurantname,
    rating,
    CEILING(rating) AS CeilRating,
    FLOOR(rating) AS FloorRating,
    ABS(rating) AS AbsRating,
    GETDATE() AS CurrentDate,
    YEAR(GETDATE()) AS CurrentYear,
    DATENAME(month, GETDATE()) AS CurrentMonth,
    DAY(GETDATE()) AS CurrentDay
FROM jomato
5
SELECT
    RestaurantType,
    AVG(averagecost) AS TotalAverageCost
FROM jomato 
GROUP BY
    ROLLUP(restauranttype);

	












	